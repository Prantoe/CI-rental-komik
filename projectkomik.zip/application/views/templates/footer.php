<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.4.0
    </div>
    <strong>Copyright &copy; 2019-2020- <a href="https://www.facebook.com/prantosoearno" target="_blank">Pranto Suwarno</a>.</strong> All rights
    reserved.
  </footer>